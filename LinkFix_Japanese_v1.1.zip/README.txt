
# LinkFix

LinkFix is a free Windows utility that lists and batch-modifies shortcut (.lnk) target paths and working directories.

---

## Features / 主な機能

- Scan all .lnk files in a folder (including subfolders)  
  フォルダ内（サブフォルダ含む）のショートカットを自動検出
- Display shortcut targets and working directories  
  リンク先と作業フォルダの一覧表示
- Batch-replace specific text in both fields  
  両方のパスを文字列一括置換
- Export results as CSV  
  CSVファイルで保存可能
- Save a log of replaced shortcuts  
  置換内容のログを自動保存
- No installation required  
  インストール不要・実行ファイルのみ

---

## Download / ダウンロード

- English version EXE: `linkfix_gui_en.exe`  
- 日本語版 EXE： `linkfix_gui_ja.exe`

---

## System Requirements / 動作環境

- Windows 10 / 11
- Python not required (EXE version)
- Python不要（EXE形式）

---

## Support / 開発支援

If you find this tool helpful, feel free to support the developer via PayPal:  
もし便利だと感じたら、開発者への支援も歓迎です！

[https://paypal.me/asukanetja?country.x=JP&locale.x=ja_JP](https://paypal.me/asukanetja?country.x=JP&locale.x=ja_JP)

---

## Developer / 開発者

Asuka Communication（あすか通信）  
Made with Python + tkinter

---

## License / ライセンス

This software is free to use for both personal and commercial purposes.  
利用は無料。商用・非商用問わず自由に使用可能です。

Use at your own risk.  
使用による損害などには責任を負いかねます。ご了承ください。
