# LinkFix v2.0

LinkFix is a free Windows utility that lists and batch-modifies or deletes shortcut (.lnk) target paths and working directories.
LinkFixは、ショートカット（.lnk）のリンク先・作業フォルダを一括で置換・削除できる無料のWindowsツールです。

---

## Features / 主な機能

- Scan all .lnk files in a folder (including subfolders)  
  フォルダ内（サブフォルダ含む）のショートカットを自動検出
- Display shortcut targets, working directories, and the folder each one is in  
  リンク先・作業フォルダ・場所（フォルダ階層）の一覧表示
- Batch-replace specific text in both fields (case-insensitive)  
  両方のパスを文字列一括置換（大文字・小文字は区別しません）
- Delete shortcuts that contain a specific address  
  特定のアドレスを含むショートカットの一括削除
- Automatic backup before changes or deletions (saved next to the exe)  
  変更・削除の前に自動バックアップ（exeと同じ場所に保存）
- Supports "network location" shortcuts (monitor icon)  
  「ネットワークの場所」形式（モニタのアイコン）のショートカットに対応
- Replace or remove pinned folders in Quick Access  
  クイックアクセスのピン留めの置換・削除
- Progress display with a cancel button  
  進捗表示と中止ボタン
- Export results as CSV  
  CSVファイルで保存可能
- Save a log of replaced shortcuts  
  置換内容のログを自動保存
- No installation required  
  インストール不要・実行ファイルのみ

Note: Quick Access changes are not backed up.  
注意：クイックアクセスの置換・削除はバックアップされません。

---

## Download / ダウンロード

- 日本語版 EXE（v2.0）： `LinkFix_ja_v2.exe`
- English version EXE (v1.1): `linkfix_gui_en.exe`

---

## System Requirements / 動作環境

- Windows 10 / 11
- Python not required (EXE version)
- Python不要（EXE形式）

---

## Developer / 開発者

Asuka Communication（あすか通信）  
Made with Python + tkinter

---

## License / ライセンス

This software is free to use for both personal and commercial purposes.  
利用は無料。商用・非商用問わず自由に使用可能です。

Use at your own risk.  
使用による損害などには責任を負いかねます。ご了承ください。
