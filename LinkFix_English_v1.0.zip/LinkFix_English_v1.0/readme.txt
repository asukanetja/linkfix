[LinkFix - English Version]

■ Overview:
LinkFix is a tool that lists and batch-modifies shortcut (.lnk) targets within a specified folder.

■ Features:
- Scan all shortcuts (including subfolders)
- Show target paths in a list
- Replace specified strings in the target paths
- Export results as CSV

■ How to Use:
1. Select the target folder
2. Click "Show Shortcuts" to review
3. Use "Execute Replace" if needed
4. Save results via "Export to CSV"

■ OS:
Windows 10 / 11

■ Version:
v1.0

■ Developer:
Asuka Communication (あすか通信)

■ Notes:
This is a free tool. Use at your own risk.
